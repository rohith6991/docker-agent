package com.stackroute.dockeragent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DockerAgentApplication {

	public static void main(String[] args) {
		SpringApplication.run(DockerAgentApplication.class, args);
	}

}

